function ChoosePeopleController($scope, $navigate) {


    //************************** 在此处编写代码 ****************************






    //************** '赵大' '钱二' '张三' '李四' '王五' '刘六' ***************






    $scope.select_user = function (user) {

    }

}
