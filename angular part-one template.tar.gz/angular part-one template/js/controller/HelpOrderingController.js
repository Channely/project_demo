function HelpOrderingController($scope, $navigate) {

    //*****************在这里添加你的代码*****************




}
